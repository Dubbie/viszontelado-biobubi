@extends('layouts.app')

@section('content')
<div class="container">
    <div class="card card-body">
        <h3>Üdvözöljük a <b class="text-primary">BioBubi Viszonteladó Portálján</b>!</h3>

        <p class="mb-0">A weboldal fejlesztése folyamatban...</p>
    </div>
</div>
@endsection
