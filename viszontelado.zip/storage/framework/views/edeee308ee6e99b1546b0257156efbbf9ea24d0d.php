<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="font-weight-bold mb-4">Felhasználók</h1>
            </div>
            <div class="col text-right">
                <a href="<?php echo e(action('UserController@create')); ?>" class="btn btn-teal shadow-sm">Új felhasználó</a>
            </div>
        </div>
        <div class="card card-body">
            <table class="table table-sm table-responsive-md table-borderless mb-0">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Név</th>
                    <th scope="col">E-mail</th>
                    <th scope="col">Ir.Számok</th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e(count($user->zips)); ?> db</td>
                        <td class="text-right">
                            <button type="button" class="btn-user-details btn-icon" data-toggle="modal" data-target="#userDetailsModal" data-user-id="<?php echo e($user->id); ?>">
                            <span class="icon">
                                <i class="fas fa-expand"></i>
                            </span>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php echo $__env->make('modal.user-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $( () => {
            const modal = document.getElementById('userDetailsModal');
            const userDetails = modal.querySelector('#user-details');
            const loading = modal.querySelector('.modal-loader');

            // Jármű részleteinek betöltése
            $(document).on('click', '.btn-user-details', (e) => {
                const userId = e.currentTarget.dataset.userId;
                $(loading).show();
                $(userDetails).hide();
                fetch('/felhasznalok/' + userId).then(response => response.text()).then(html => {
                    userDetails.innerHTML = html;
                    $(loading).hide();
                    $(userDetails).show();
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\www\semmiszemet\viszontelado\resources\views/user/index.blade.php ENDPATH**/ ?>