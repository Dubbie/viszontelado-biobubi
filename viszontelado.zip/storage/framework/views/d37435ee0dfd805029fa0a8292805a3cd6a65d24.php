<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <p class="mb-0">
                    <a href="<?php echo e(action('UserController@index')); ?>" class="btn btn-sm btn-link px-0 text-muted text-decoration-none">
                        <span class="icon icon-sm">
                            <i class="fas fa-arrow-left"></i>
                        </span>
                        <span>Vissza a felhasználókhoz</span>
                    </a>
                </p>
                <div class="row">
                    <div class="col">
                        <h3 class="font-weight-bold mb-4">Új felhasználó</h3>
                    </div>
                </div>
                <div class="card card-body">
                    <form action="<?php echo e(action('UserController@store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="u-name">Név <small class="text-muted">Ez a viszonteladó neve</small></label>
                            <input type="text" id="u-name" name="u-name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="u-email">E-mail cím <small class="text-muted">Ez a viszonteladó e-mail címe amivel be tud majd lépni</small></label>
                            <input type="email" id="u-email" name="u-email" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="u-password">Jelszó <small class="text-muted">Az itt megadott jelszóval tud majd belépni</small></label>
                            <input type="password" id="u-password" name="u-password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="u-zip">Hozzárendelt irányítószámok <small class="text-muted">Az itt megadott irányítószámokra fog szűrni a rendszer</small></label>
                            <input type="text" id="u-zip" name="u-zip" class="form-control" required>
                        </div>
                        <div class="form-group mb-0 text-right">
                            <button type="submit" class="btn btn-sm btn-success">Felhasználó létrehozása</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const inputZip = document.getElementById('u-zip');

        const tagify = new Tagify(inputZip);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\www\semmiszemet\viszontelado\resources\views/user/create.blade.php ENDPATH**/ ?>