<h3 class="font-weight-bold mb-1"><?php echo e($user->name); ?></h3>
<h5 class="font-weight-bold text-muted mb-4"><?php echo e($user->email); ?></h5>

<p class="font-weight-bold mb-1">Hozzárendelt irányítószámok</p>
<ul class="list-unstyled">
    <?php $__currentLoopData = $user->zips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($zip->zip); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\dev\www\semmiszemet\viszontelado\resources\views/inc/user-details-content.blade.php ENDPATH**/ ?>