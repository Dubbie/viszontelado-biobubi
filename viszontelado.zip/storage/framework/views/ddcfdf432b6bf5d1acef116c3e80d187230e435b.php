<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card card-body">
        <h3>Üdvözöljük a <b class="text-primary">BioBubi Viszonteladó Portálján</b>!</h3>

        <p class="mb-0">A weboldal fejlesztése folyamatban...</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\www\semmiszemet\viszontelado\resources\views/home.blade.php ENDPATH**/ ?>