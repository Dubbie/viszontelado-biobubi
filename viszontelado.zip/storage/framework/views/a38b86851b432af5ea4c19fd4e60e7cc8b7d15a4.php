<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="alert alert-info">
            <p class="mb-0">Jelenleg az összes megrendelés látható (max. 200), a szűrés implementálása jelenleg aktívan zajlik.</p>
        </div>
        <div class="card card-body">
            <table class="table table-sm table-borderless mb-0">
                <thead>
                <tr>
                    <th scope="col"><small class="font-weight-bold">Ügyfél neve/e-mail címe</small></th>
                    <th scope="col"><small class="font-weight-bold">Állapot</small></th>
                    <th scope="col"><small class="font-weight-bold">Szállítási mód</small></th>
                    <th scope="col"><small class="font-weight-bold">Fizetési mód</small></th>
                    <th scope="col"><small class="font-weight-bold">Kezdő dátum</small></th>
                    <th scope="col" class="text-right"><small class="font-weight-bold">Összesen</small></th>
                    <td></td>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><p class="mb-0"><?php echo e($order->lastname); ?> <?php echo e($order->firstname); ?><small class="d-block"><?php echo e($order->email); ?></small></p></td>
                        <td><p class="mb-0">Státusz</p></td>
                        <td><p class="mb-0"><?php echo e($order->shippingMethodName); ?></p></td>
                        <td><p class="mb-0"><?php echo e($order->paymentMethodName); ?></p></td>
                        <td><p class="mb-0"><?php echo e(date('Y. m. d. H:i', strtotime($order->dateCreated))); ?></p></td>
                        <td class="text-right"><p class="mb-0"><?php echo e(number_format($order->total, 0, '.', ' ')); ?> Ft</p></td>
                        <td>
                            <a href="<?php echo e(action('OrderController@show', ['orderId' => $order->id])); ?>" class="btn btn-sm btn-outline-secondary">Részletek</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\www\semmiszemet\viszontelado\resources\views/order/index.blade.php ENDPATH**/ ?>